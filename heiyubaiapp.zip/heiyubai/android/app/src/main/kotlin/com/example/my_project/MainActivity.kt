package com.heiyubai.restaurante.chino

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
