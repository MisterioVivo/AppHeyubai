import 'package:flutter/material.dart';
import 'flutter_flow/request_manager.dart';
import '/backend/backend.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _USR = prefs.getStringList('ff_USR')?.map((path) => path.ref).toList() ??
          _USR;
    });
    _safeInit(() {
      _producto = prefs
              .getStringList('ff_producto')
              ?.map((path) => path.ref)
              .toList() ??
          _producto;
    });
    _safeInit(() {
      _dirccion = prefs.getString('ff_dirccion') ?? _dirccion;
    });
    _safeInit(() {
      _zona = prefs.getString('ff_zona') ?? _zona;
    });
    _safeInit(() {
      _barrio = prefs.getString('ff_barrio') ?? _barrio;
    });
    _safeInit(() {
      _numro = prefs.getString('ff_numro') ?? _numro;
    });
    _safeInit(() {
      _nombr = prefs.getString('ff_nombr') ?? _nombr;
    });
    _safeInit(() {
      _adicional = prefs.getString('ff_adicional') ?? _adicional;
    });
    _safeInit(() {
      _cart = prefs.getString('ff_cart')?.ref ?? _cart;
    });
    _safeInit(() {
      _gmail = prefs.getString('ff_gmail') ?? _gmail;
    });
    _safeInit(() {
      _fcha = prefs.containsKey('ff_fcha')
          ? DateTime.fromMillisecondsSinceEpoch(prefs.getInt('ff_fcha')!)
          : _fcha;
    });
    _safeInit(() {
      _ubi = prefs.getString('ff_ubi') ?? _ubi;
    });
    _safeInit(() {
      _Bottonpago = prefs.getBool('ff_Bottonpago') ?? _Bottonpago;
    });
    _safeInit(() {
      _darkmode = prefs.getBool('ff_darkmode') ?? _darkmode;
    });
    _safeInit(() {
      _ky = prefs.getString('ff_ky') ?? _ky;
    });
    _safeInit(() {
      _acompnante = prefs.getString('ff_acompnante') ?? _acompnante;
    });
    _safeInit(() {
      _acompaante2 = prefs.getString('ff_acompaante2') ?? _acompaante2;
    });
    _safeInit(() {
      _ticket = prefs.getInt('ff_ticket') ?? _ticket;
    });
    _safeInit(() {
      _tickr2 = prefs.getInt('ff_tickr2') ?? _tickr2;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _rol = false;
  bool get rol => _rol;
  set rol(bool value) {
    _rol = value;
  }

  int _pago = 1;
  int get pago => _pago;
  set pago(int value) {
    _pago = value;
  }

  bool _tomado = false;
  bool get tomado => _tomado;
  set tomado(bool value) {
    _tomado = value;
  }

  double _nomostrar = 0.0;
  double get nomostrar => _nomostrar;
  set nomostrar(double value) {
    _nomostrar = value;
  }

  bool _buscar = false;
  bool get buscar => _buscar;
  set buscar(bool value) {
    _buscar = value;
  }

  bool _selector1 = false;
  bool get selector1 => _selector1;
  set selector1(bool value) {
    _selector1 = value;
  }

  bool _selector2 = false;
  bool get selector2 => _selector2;
  set selector2(bool value) {
    _selector2 = value;
  }

  String _arrozreset = '';
  String get arrozreset => _arrozreset;
  set arrozreset(String value) {
    _arrozreset = value;
  }

  String _acompananterest = '';
  String get acompananterest => _acompananterest;
  set acompananterest(String value) {
    _acompananterest = value;
  }

  bool _ckeboxx = false;
  bool get ckeboxx => _ckeboxx;
  set ckeboxx(bool value) {
    _ckeboxx = value;
  }

  bool _ckebox1 = false;
  bool get ckebox1 => _ckebox1;
  set ckebox1(bool value) {
    _ckebox1 = value;
  }

  bool _buscando = false;
  bool get buscando => _buscando;
  set buscando(bool value) {
    _buscando = value;
  }

  bool _BUS = false;
  bool get BUS => _BUS;
  set BUS(bool value) {
    _BUS = value;
  }

  Color _cambio = Color(4294967295);
  Color get cambio => _cambio;
  set cambio(Color value) {
    _cambio = value;
  }

  bool _menu = false;
  bool get menu => _menu;
  set menu(bool value) {
    _menu = value;
  }

  String _id = '';
  String get id => _id;
  set id(String value) {
    _id = value;
  }

  bool _selectorcheck = false;
  bool get selectorcheck => _selectorcheck;
  set selectorcheck(bool value) {
    _selectorcheck = value;
  }

  bool _selectordrop = false;
  bool get selectordrop => _selectordrop;
  set selectordrop(bool value) {
    _selectordrop = value;
  }

  bool _confirmacion = false;
  bool get confirmacion => _confirmacion;
  set confirmacion(bool value) {
    _confirmacion = value;
  }

  List<DocumentReference> _USR = [
    FirebaseFirestore.instance.doc('/usuarios/lcAMptfP0cP1LVydXLruZdnZaoH3')
  ];
  List<DocumentReference> get USR => _USR;
  set USR(List<DocumentReference> value) {
    _USR = value;
    prefs.setStringList('ff_USR', value.map((x) => x.path).toList());
  }

  void addToUSR(DocumentReference value) {
    USR.add(value);
    prefs.setStringList('ff_USR', _USR.map((x) => x.path).toList());
  }

  void removeFromUSR(DocumentReference value) {
    USR.remove(value);
    prefs.setStringList('ff_USR', _USR.map((x) => x.path).toList());
  }

  void removeAtIndexFromUSR(int index) {
    USR.removeAt(index);
    prefs.setStringList('ff_USR', _USR.map((x) => x.path).toList());
  }

  void updateUSRAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    USR[index] = updateFn(_USR[index]);
    prefs.setStringList('ff_USR', _USR.map((x) => x.path).toList());
  }

  void insertAtIndexInUSR(int index, DocumentReference value) {
    USR.insert(index, value);
    prefs.setStringList('ff_USR', _USR.map((x) => x.path).toList());
  }

  List<DocumentReference> _producto = [];
  List<DocumentReference> get producto => _producto;
  set producto(List<DocumentReference> value) {
    _producto = value;
    prefs.setStringList('ff_producto', value.map((x) => x.path).toList());
  }

  void addToProducto(DocumentReference value) {
    producto.add(value);
    prefs.setStringList('ff_producto', _producto.map((x) => x.path).toList());
  }

  void removeFromProducto(DocumentReference value) {
    producto.remove(value);
    prefs.setStringList('ff_producto', _producto.map((x) => x.path).toList());
  }

  void removeAtIndexFromProducto(int index) {
    producto.removeAt(index);
    prefs.setStringList('ff_producto', _producto.map((x) => x.path).toList());
  }

  void updateProductoAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    producto[index] = updateFn(_producto[index]);
    prefs.setStringList('ff_producto', _producto.map((x) => x.path).toList());
  }

  void insertAtIndexInProducto(int index, DocumentReference value) {
    producto.insert(index, value);
    prefs.setStringList('ff_producto', _producto.map((x) => x.path).toList());
  }

  String _dirccion = '';
  String get dirccion => _dirccion;
  set dirccion(String value) {
    _dirccion = value;
    prefs.setString('ff_dirccion', value);
  }

  String _zona = '';
  String get zona => _zona;
  set zona(String value) {
    _zona = value;
    prefs.setString('ff_zona', value);
  }

  String _barrio = '';
  String get barrio => _barrio;
  set barrio(String value) {
    _barrio = value;
    prefs.setString('ff_barrio', value);
  }

  String _numro = '';
  String get numro => _numro;
  set numro(String value) {
    _numro = value;
    prefs.setString('ff_numro', value);
  }

  String _nombr = '';
  String get nombr => _nombr;
  set nombr(String value) {
    _nombr = value;
    prefs.setString('ff_nombr', value);
  }

  String _adicional = '';
  String get adicional => _adicional;
  set adicional(String value) {
    _adicional = value;
    prefs.setString('ff_adicional', value);
  }

  DocumentReference? _cart;
  DocumentReference? get cart => _cart;
  set cart(DocumentReference? value) {
    _cart = value;
    value != null
        ? prefs.setString('ff_cart', value.path)
        : prefs.remove('ff_cart');
  }

  String _gmail = '';
  String get gmail => _gmail;
  set gmail(String value) {
    _gmail = value;
    prefs.setString('ff_gmail', value);
  }

  DateTime? _fcha;
  DateTime? get fcha => _fcha;
  set fcha(DateTime? value) {
    _fcha = value;
    value != null
        ? prefs.setInt('ff_fcha', value.millisecondsSinceEpoch)
        : prefs.remove('ff_fcha');
  }

  String _ubi = '';
  String get ubi => _ubi;
  set ubi(String value) {
    _ubi = value;
    prefs.setString('ff_ubi', value);
  }

  bool _Bottonpago = false;
  bool get Bottonpago => _Bottonpago;
  set Bottonpago(bool value) {
    _Bottonpago = value;
    prefs.setBool('ff_Bottonpago', value);
  }

  bool _darkmode = false;
  bool get darkmode => _darkmode;
  set darkmode(bool value) {
    _darkmode = value;
    prefs.setBool('ff_darkmode', value);
  }

  String _aompaant = '';
  String get aompaant => _aompaant;
  set aompaant(String value) {
    _aompaant = value;
  }

  String _otros = '';
  String get otros => _otros;
  set otros(String value) {
    _otros = value;
  }

  String _ky = '';
  String get ky => _ky;
  set ky(String value) {
    _ky = value;
    prefs.setString('ff_ky', value);
  }

  String _dscrpcionusuario = '';
  String get dscrpcionusuario => _dscrpcionusuario;
  set dscrpcionusuario(String value) {
    _dscrpcionusuario = value;
  }

  String _email = '';
  String get email => _email;
  set email(String value) {
    _email = value;
  }

  bool _terminosycondiciones = false;
  bool get terminosycondiciones => _terminosycondiciones;
  set terminosycondiciones(bool value) {
    _terminosycondiciones = value;
  }

  bool _aceptacionterminos = false;
  bool get aceptacionterminos => _aceptacionterminos;
  set aceptacionterminos(bool value) {
    _aceptacionterminos = value;
  }

  bool _contraentrega = false;
  bool get contraentrega => _contraentrega;
  set contraentrega(bool value) {
    _contraentrega = value;
  }

  bool _metodosdepago = false;
  bool get metodosdepago => _metodosdepago;
  set metodosdepago(bool value) {
    _metodosdepago = value;
  }

  String _random = '';
  String get random => _random;
  set random(String value) {
    _random = value;
  }

  int _codigotickect = 0;
  int get codigotickect => _codigotickect;
  set codigotickect(int value) {
    _codigotickect = value;
  }

  String _acompnante = '';
  String get acompnante => _acompnante;
  set acompnante(String value) {
    _acompnante = value;
    prefs.setString('ff_acompnante', value);
  }

  String _acompaante2 = '';
  String get acompaante2 => _acompaante2;
  set acompaante2(String value) {
    _acompaante2 = value;
    prefs.setString('ff_acompaante2', value);
  }

  int _ticket = 0;
  int get ticket => _ticket;
  set ticket(int value) {
    _ticket = value;
    prefs.setInt('ff_ticket', value);
  }

  int _tickr2 = 0;
  int get tickr2 => _tickr2;
  set tickr2(int value) {
    _tickr2 = value;
    prefs.setInt('ff_tickr2', value);
  }

  final _optimizacionmenuManager =
      StreamRequestManager<List<ProductosRecord>>();
  Stream<List<ProductosRecord>> optimizacionmenu({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<ProductosRecord>> Function() requestFn,
  }) =>
      _optimizacionmenuManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearOptimizacionmenuCache() => _optimizacionmenuManager.clear();
  void clearOptimizacionmenuCacheKey(String? uniqueKey) =>
      _optimizacionmenuManager.clearRequest(uniqueKey);

  final _categoriasCacheManager = StreamRequestManager<List<ProductosRecord>>();
  Stream<List<ProductosRecord>> categoriasCache({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<ProductosRecord>> Function() requestFn,
  }) =>
      _categoriasCacheManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCategoriasCacheCache() => _categoriasCacheManager.clear();
  void clearCategoriasCacheCacheKey(String? uniqueKey) =>
      _categoriasCacheManager.clearRequest(uniqueKey);
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

Color? _colorFromIntValue(int? val) {
  if (val == null) {
    return null;
  }
  return Color(val);
}
