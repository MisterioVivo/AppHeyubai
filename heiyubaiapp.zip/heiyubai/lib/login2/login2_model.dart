import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'login2_widget.dart' show Login2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Login2Model extends FlutterFlowModel<Login2Widget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Correo widget.
  FocusNode? correoFocusNode;
  TextEditingController? correoTextController;
  String? Function(BuildContext, String?)? correoTextControllerValidator;
  // State field(s) for contrasena1 widget.
  FocusNode? contrasena1FocusNode;
  TextEditingController? contrasena1TextController;
  late bool contrasena1Visibility;
  String? Function(BuildContext, String?)? contrasena1TextControllerValidator;
  // State field(s) for contrasena2 widget.
  FocusNode? contrasena2FocusNode;
  TextEditingController? contrasena2TextController;
  late bool contrasena2Visibility;
  String? Function(BuildContext, String?)? contrasena2TextControllerValidator;

  @override
  void initState(BuildContext context) {
    contrasena1Visibility = false;
    contrasena2Visibility = false;
  }

  @override
  void dispose() {
    correoFocusNode?.dispose();
    correoTextController?.dispose();

    contrasena1FocusNode?.dispose();
    contrasena1TextController?.dispose();

    contrasena2FocusNode?.dispose();
    contrasena2TextController?.dispose();
  }
}
