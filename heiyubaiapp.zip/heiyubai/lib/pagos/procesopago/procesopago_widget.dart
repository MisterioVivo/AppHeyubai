import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'procesopago_model.dart';
export 'procesopago_model.dart';

class ProcesopagoWidget extends StatefulWidget {
  const ProcesopagoWidget({super.key});

  @override
  State<ProcesopagoWidget> createState() => _ProcesopagoWidgetState();
}

class _ProcesopagoWidgetState extends State<ProcesopagoWidget> {
  late ProcesopagoModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ProcesopagoModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (valueOrDefault<bool>(
                              currentUserDocument?.pago, false) ==
                          false)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 100.0, 10.0, 20.0),
                          child: AuthUserStreamWidget(
                            builder: (context) => Text(
                              'Estamos Procesando tu Pago',
                              textAlign: TextAlign.center,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Montserrat',
                                    color: Colors.black,
                                    fontSize: 30.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ),
                        ),
                      if (valueOrDefault<bool>(
                              currentUserDocument?.pago, false) ==
                          true)
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 100.0, 10.0, 20.0),
                          child: AuthUserStreamWidget(
                            builder: (context) => Text(
                              'Pago Realizado Con Exito',
                              textAlign: TextAlign.center,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Montserrat',
                                    color: Colors.black,
                                    fontSize: 30.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ),
                        ),
                      if (valueOrDefault<bool>(
                              currentUserDocument?.pago, false) ==
                          true)
                        Padding(
                          padding: EdgeInsets.all(10.0),
                          child: AuthUserStreamWidget(
                            builder: (context) => Lottie.asset(
                              'assets/jsons/Animation_-_1726074238025.json',
                              width: 417.0,
                              height: 407.0,
                              fit: BoxFit.contain,
                              animate: true,
                            ),
                          ),
                        ),
                    ]
                        .divide(SizedBox(height: 8.0))
                        .addToEnd(SizedBox(height: 16.0)),
                  ),
                ),
                if (valueOrDefault<bool>(currentUserDocument?.pago, false) ==
                    false)
                  AuthUserStreamWidget(
                    builder: (context) => Container(
                      width: 220.0,
                      height: 253.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Lottie.asset(
                        'assets/jsons/Animation_-_1726073741696.json',
                        width: 200.0,
                        height: 200.0,
                        fit: BoxFit.contain,
                        animate: true,
                      ),
                    ),
                  ),
                if (valueOrDefault<bool>(currentUserDocument?.pago, false) ==
                    true)
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 40.0, 0.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => StreamBuilder<List<CartRecord>>(
                        stream: queryCartRecord(
                          queryBuilder: (cartRecord) => cartRecord.where(
                            'creator',
                            isEqualTo: currentUserReference,
                          ),
                          singleRecord: true,
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    FlutterFlowTheme.of(context).primary,
                                  ),
                                ),
                              ),
                            );
                          }
                          List<CartRecord> buttonCartRecordList =
                              snapshot.data!;
                          final buttonCartRecord =
                              buttonCartRecordList.isNotEmpty
                                  ? buttonCartRecordList.first
                                  : null;

                          return FFButtonWidget(
                            onPressed: () async {
                              context.pushNamed('menu1');

                              await buttonCartRecord!.reference.delete();
                            },
                            text: 'Ir al menu',
                            icon: FaIcon(
                              FontAwesomeIcons.home,
                              color: Colors.black,
                              size: 15.0,
                            ),
                            options: FFButtonOptions(
                              width: 200.0,
                              height: 40.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  24.0, 0.0, 24.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: Colors.white,
                              textStyle: FlutterFlowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Montserrat',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                              elevation: 3.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                if (valueOrDefault<bool>(currentUserDocument?.pago, false) ==
                    false)
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 40.0, 0.0, 0.0),
                    child: AuthUserStreamWidget(
                      builder: (context) => FFButtonWidget(
                        onPressed: () async {
                          context.pushNamed('menu1');
                        },
                        text: 'Ir al menu',
                        icon: FaIcon(
                          FontAwesomeIcons.home,
                          color: Colors.black,
                          size: 15.0,
                        ),
                        options: FFButtonOptions(
                          width: 200.0,
                          height: 40.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              24.0, 0.0, 24.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: Colors.white,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Montserrat',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                          elevation: 3.0,
                          borderSide: BorderSide(
                            color: Colors.transparent,
                            width: 1.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
