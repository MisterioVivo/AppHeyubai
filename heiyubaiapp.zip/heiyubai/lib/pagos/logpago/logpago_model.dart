import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'logpago_widget.dart' show LogpagoWidget;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LogpagoModel extends FlutterFlowModel<LogpagoWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Correo widget.
  FocusNode? correoFocusNode;
  TextEditingController? correoTextController;
  String? Function(BuildContext, String?)? correoTextControllerValidator;
  // State field(s) for contra1 widget.
  FocusNode? contra1FocusNode;
  TextEditingController? contra1TextController;
  late bool contra1Visibility;
  String? Function(BuildContext, String?)? contra1TextControllerValidator;

  @override
  void initState(BuildContext context) {
    contra1Visibility = false;
  }

  @override
  void dispose() {
    correoFocusNode?.dispose();
    correoTextController?.dispose();

    contra1FocusNode?.dispose();
    contra1TextController?.dispose();
  }
}
