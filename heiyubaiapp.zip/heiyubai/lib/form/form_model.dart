import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/card19_comment_box_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'form_widget.dart' show FormWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FormModel extends FlutterFlowModel<FormWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for Direccion widget.
  FocusNode? direccionFocusNode;
  TextEditingController? direccionTextController;
  String? Function(BuildContext, String?)? direccionTextControllerValidator;
  String? _direccionTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Dato Requerido.';
    }

    return null;
  }

  // State field(s) for Zona widget.
  String? zonaValue;
  FormFieldController<String>? zonaValueController;
  // State field(s) for Barrio widget.
  FocusNode? barrioFocusNode;
  TextEditingController? barrioTextController;
  String? Function(BuildContext, String?)? barrioTextControllerValidator;
  String? _barrioTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Dato Requerido.';
    }

    return null;
  }

  // State field(s) for Numero widget.
  FocusNode? numeroFocusNode;
  TextEditingController? numeroTextController;
  String? Function(BuildContext, String?)? numeroTextControllerValidator;
  String? _numeroTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Dato Requerido.';
    }

    return null;
  }

  // State field(s) for Nombre widget.
  FocusNode? nombreFocusNode;
  TextEditingController? nombreTextController;
  String? Function(BuildContext, String?)? nombreTextControllerValidator;
  String? _nombreTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Dato Requerido.';
    }

    return null;
  }

  // Model for Informacion.
  late Card19CommentBoxModel informacionModel;

  @override
  void initState(BuildContext context) {
    direccionTextControllerValidator = _direccionTextControllerValidator;
    barrioTextControllerValidator = _barrioTextControllerValidator;
    numeroTextControllerValidator = _numeroTextControllerValidator;
    nombreTextControllerValidator = _nombreTextControllerValidator;
    informacionModel = createModel(context, () => Card19CommentBoxModel());
    informacionModel.textControllerValidator = _formTextFieldValidator;
  }

  @override
  void dispose() {
    direccionFocusNode?.dispose();
    direccionTextController?.dispose();

    barrioFocusNode?.dispose();
    barrioTextController?.dispose();

    numeroFocusNode?.dispose();
    numeroTextController?.dispose();

    nombreFocusNode?.dispose();
    nombreTextController?.dispose();

    informacionModel.dispose();
  }

  /// Additional helper methods.

  String? _formTextFieldValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Dato Requerido.';
    }

    return null;
  }
}
