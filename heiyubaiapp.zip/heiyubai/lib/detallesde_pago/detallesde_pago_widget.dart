import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/random_data_util.dart' as random_data;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'detallesde_pago_model.dart';
export 'detallesde_pago_model.dart';

class DetallesdePagoWidget extends StatefulWidget {
  const DetallesdePagoWidget({
    super.key,
    required this.cantidadpagar,
    required this.dirrewcion,
    required this.zona,
    required this.barrio,
    required this.numero,
    required this.nombre,
    required this.ref,
    required this.adicionar,
  });

  final double? cantidadpagar;
  final String? dirrewcion;
  final String? zona;
  final String? barrio;
  final String? numero;
  final String? nombre;
  final DocumentReference? ref;
  final String? adicionar;

  @override
  State<DetallesdePagoWidget> createState() => _DetallesdePagoWidgetState();
}

class _DetallesdePagoWidgetState extends State<DetallesdePagoWidget> {
  late DetallesdePagoModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DetallesdePagoModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).tertiary,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(50.0, 0.0, 0.0, 0.0),
                child: Text(
                  'Detalle De Pago',
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                        fontFamily: 'Inter',
                        color: FlutterFlowTheme.of(context).tertiary,
                        letterSpacing: 0.0,
                      ),
                ),
              ),
            ],
          ),
          actions: [],
          centerTitle: false,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(16.0, 4.0, 16.0, 16.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                        child: Text(
                          'Tus Datos',
                          style: FlutterFlowTheme.of(context)
                              .bodyLarge
                              .override(
                                fontFamily: 'Readex Pro',
                                color: FlutterFlowTheme.of(context).tertiary,
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                            borderRadius: BorderRadius.circular(12.0),
                            border: Border.all(
                              color: FlutterFlowTheme.of(context).tertiary,
                              width: 2.0,
                            ),
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(12.0),
                            child: Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      12.0, 0.0, 0.0, 0.0),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        valueOrDefault<String>(
                                          widget!.nombre,
                                          's',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyLarge
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .tertiary,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                      Text(
                                        valueOrDefault<String>(
                                          widget!.numero,
                                          '2',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyLarge
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .tertiary,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                      Text(
                                        valueOrDefault<String>(
                                          widget!.dirrewcion,
                                          's',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyLarge
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .tertiary,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                      Text(
                                        valueOrDefault<String>(
                                          widget!.barrio,
                                          's',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyLarge
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .tertiary,
                                              fontSize: 16.0,
                                              letterSpacing: 0.0,
                                            ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 4.0, 0.0, 0.0),
                                        child: Text(
                                          valueOrDefault<String>(
                                            widget!.zona,
                                            's',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .labelSmall
                                              .override(
                                                fontFamily: 'Readex Pro',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryText,
                                                fontSize: 20.0,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 16.0, 0.0, 16.0),
                        child: Divider(
                          thickness: 2.0,
                          color: FlutterFlowTheme.of(context).tertiary,
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 12.0),
                        child: Text(
                          'A PAGAR',
                          style: FlutterFlowTheme.of(context)
                              .bodyLarge
                              .override(
                                fontFamily: 'Readex Pro',
                                color: FlutterFlowTheme.of(context).tertiary,
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'COMIDA',
                              style: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Text(
                              formatNumber(
                                widget!.cantidadpagar,
                                formatType: FormatType.decimal,
                                decimalType: DecimalType.automatic,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'DOMICILIO',
                              style: FlutterFlowTheme.of(context)
                                  .labelMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Text(
                              () {
                                if (widget!.zona == 'sur') {
                                  return '4000';
                                } else if (widget!.zona == 'norte') {
                                  return '2000';
                                } else if (widget!.zona == 'oriente') {
                                  return '3000';
                                } else if (widget!.zona == 'otro') {
                                  return '8000';
                                } else {
                                  return '0';
                                }
                              }(),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Total',
                              style: FlutterFlowTheme.of(context)
                                  .labelLarge
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    letterSpacing: 0.0,
                                  ),
                            ),
                            Text(
                              valueOrDefault<String>(
                                formatNumber(
                                  (widget!.cantidadpagar!) +
                                      () {
                                        if (widget!.zona == 'sur') {
                                          return 4000.0;
                                        } else if (widget!.zona == 'norte') {
                                          return 2000.0;
                                        } else if (widget!.zona == 'oriente') {
                                          return 3000.0;
                                        } else if (widget!.zona == 'otro') {
                                          return 8000.0;
                                        } else {
                                          return 0.0;
                                        }
                                      }(),
                                  formatType: FormatType.decimal,
                                  decimalType: DecimalType.automatic,
                                ),
                                '0',
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Inter',
                                    color:
                                        FlutterFlowTheme.of(context).tertiary,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 16.0, 0.0, 16.0),
                        child: Divider(
                          thickness: 2.0,
                          color: FlutterFlowTheme.of(context).tertiary,
                        ),
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(-1.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Theme(
                        data: ThemeData(
                          checkboxTheme: CheckboxThemeData(
                            shape: CircleBorder(),
                          ),
                          unselectedWidgetColor:
                              FlutterFlowTheme.of(context).tertiary,
                        ),
                        child: Checkbox(
                          value: _model.checkboxValue1 ??= false,
                          onChanged: (newValue) async {
                            safeSetState(
                                () => _model.checkboxValue1 = newValue!);
                            if (newValue!) {
                              FFAppState().contraentrega = true;
                              FFAppState().metodosdepago = false;
                              safeSetState(() {});
                              safeSetState(() {
                                _model.checkboxValue2 = false;
                              });
                            }
                          },
                          side: BorderSide(
                            width: 2,
                            color: FlutterFlowTheme.of(context).tertiary,
                          ),
                          activeColor: FlutterFlowTheme.of(context).tertiary,
                          checkColor: FlutterFlowTheme.of(context).primary,
                        ),
                      ),
                      Text(
                        ' Pagar contra entrega',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Readex Pro',
                              color: FlutterFlowTheme.of(context).tertiary,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Theme(
                      data: ThemeData(
                        checkboxTheme: CheckboxThemeData(
                          shape: CircleBorder(),
                        ),
                        unselectedWidgetColor:
                            FlutterFlowTheme.of(context).tertiary,
                      ),
                      child: Checkbox(
                        value: _model.checkboxValue2 ??= false,
                        onChanged: (newValue) async {
                          safeSetState(() => _model.checkboxValue2 = newValue!);
                          if (newValue!) {
                            FFAppState().metodosdepago = true;
                            FFAppState().contraentrega = false;
                            safeSetState(() {});
                            safeSetState(() {
                              _model.checkboxValue1 = false;
                            });
                          }
                        },
                        side: BorderSide(
                          width: 2,
                          color: FlutterFlowTheme.of(context).tertiary,
                        ),
                        activeColor: FlutterFlowTheme.of(context).tertiary,
                        checkColor: FlutterFlowTheme.of(context).primary,
                      ),
                    ),
                    Text(
                      'Otro metodo de pago',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            color: FlutterFlowTheme.of(context).tertiary,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ],
                ),
                if (FFAppState().metodosdepago == true)
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 16.0, 30.0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        if (FFAppState().pago == 1) {
                          _model.apiResultcjtmmzb =
                              await CrearPreferenciasCall.call(
                            id: random_data.randomString(
                              8,
                              10,
                              true,
                              true,
                              true,
                            ),
                            zipCode: '1234',
                            streetNumber: 123456.0,
                            streetName: 'calee',
                            precio: valueOrDefault<double>(
                              (widget!.cantidadpagar!) +
                                  () {
                                    if (widget!.zona == 'sur') {
                                      return 4000.0;
                                    } else if (widget!.zona == 'norte') {
                                      return 2000.0;
                                    } else if (widget!.zona == 'oriente') {
                                      return 3000.0;
                                    } else if (widget!.zona == 'otro') {
                                      return 8000.0;
                                    } else {
                                      return 0.0;
                                    }
                                  }(),
                              0.0,
                            ),
                            descripcion: 'pago restaurante Heiyubai',
                            titulo: 'producto',
                            failure:
                                'https://boxwood-tree-437122-s0.flutterflow.app/PAGFALLIDO',
                            success:
                                'https://boxwood-tree-437122-s0.flutterflow.app/LOGPAGO',
                            number: 12346,
                            email: currentUserEmail,
                            surname: currentUserDisplayName,
                            name: currentUserDisplayName,
                            pending:
                                'https://boxwood-tree-437122-s0.flutterflow.app/PAGFALLIDO',
                          );

                          await currentUserReference!
                              .update(createUsuariosRecordData(
                            pago: false,
                          ));
                          await actions.pagar(
                            CrearPreferenciasCall.url(
                              (_model.apiResultcjtmmzb?.jsonBody ?? ''),
                            ),
                            Color(0xFF333232),
                          );

                          context.pushNamed('PROCESOPAGO');
                        }

                        safeSetState(() {});
                      },
                      text: 'Mercado Pago!',
                      icon: Icon(
                        Icons.credit_card_rounded,
                        size: 30.0,
                      ),
                      options: FFButtonOptions(
                        width: double.infinity,
                        height: 60.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Colors.black,
                        textStyle:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  fontFamily: 'Inter',
                                  color: Colors.white,
                                  fontSize: 20.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                        elevation: 3.0,
                        borderRadius: BorderRadius.circular(50.0),
                      ),
                    ),
                  ),
                if (FFAppState().contraentrega == true)
                  Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 16.0, 30.0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        FFAppState().ticket = valueOrDefault<int>(
                          functions.codigorandom(),
                          0,
                        );
                        safeSetState(() {});

                        await PdidospagosRecord.collection.doc().set({
                          ...createPdidospagosRecordData(
                            dirccion: widget!.dirrewcion,
                            zona: widget!.zona,
                            barrio: widget!.barrio,
                            numro: widget!.numero,
                            nombr: widget!.nombre,
                            adisional: widget!.adicionar,
                            cart: FFAppState().cart,
                            email: currentUserEmail,
                            fecha: getCurrentTimestamp,
                            acompaant: FFAppState().acompnante,
                            rfusr: currentUserReference,
                            aco: valueOrDefault(
                                currentUserDocument?.acompaant, ''),
                            otro: FFAppState().acompaante2,
                            estado: 'proceso',
                            tickect: FFAppState().ticket,
                            cart2: currentUserDocument?.cart2,
                          ),
                          ...mapToFirestore(
                            {
                              'rf': FFAppState().producto,
                            },
                          ),
                        });

                        context.pushNamed(
                          'contraentregafinalizada',
                          queryParameters: {
                            'pagototal': serializeParam(
                              valueOrDefault<double>(
                                (widget!.cantidadpagar!) +
                                    () {
                                      if (widget!.zona == 'sur') {
                                        return 4000.0;
                                      } else if (widget!.zona == 'norte') {
                                        return 2000.0;
                                      } else if (widget!.zona == 'oriente') {
                                        return 3000.0;
                                      } else if (widget!.zona == 'otro') {
                                        return 8000.0;
                                      } else {
                                        return 0.0;
                                      }
                                    }(),
                                0.0,
                              ),
                              ParamType.double,
                            ),
                          }.withoutNulls,
                          extra: <String, dynamic>{
                            kTransitionInfoKey: TransitionInfo(
                              hasTransition: true,
                              transitionType: PageTransitionType.bottomToTop,
                            ),
                          },
                        );
                      },
                      text: 'Contra Entrega',
                      icon: Icon(
                        Icons.attach_money_rounded,
                        size: 30.0,
                      ),
                      options: FFButtonOptions(
                        width: double.infinity,
                        height: 60.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Colors.black,
                        textStyle:
                            FlutterFlowTheme.of(context).headlineSmall.override(
                                  fontFamily: 'Inter',
                                  color: Colors.white,
                                  fontSize: 20.0,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.w500,
                                ),
                        elevation: 3.0,
                        borderRadius: BorderRadius.circular(50.0),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
