import '/components/aceptaciondeterminosycondiciones_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'terminosycondiciones_widget.dart' show TerminosycondicionesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TerminosycondicionesModel
    extends FlutterFlowModel<TerminosycondicionesWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for terminoscondiciones widget.
  bool? terminoscondicionesValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
