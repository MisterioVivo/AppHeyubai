import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'acompanateprivado_model.dart';
export 'acompanateprivado_model.dart';

class AcompanateprivadoWidget extends StatefulWidget {
  const AcompanateprivadoWidget({
    super.key,
    required this.esconder,
    required this.acompa,
  });

  final String? esconder;
  final String? acompa;

  @override
  State<AcompanateprivadoWidget> createState() =>
      _AcompanateprivadoWidgetState();
}

class _AcompanateprivadoWidgetState extends State<AcompanateprivadoWidget> {
  late AcompanateprivadoModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AcompanateprivadoModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 12.0),
        child: Material(
          color: Colors.transparent,
          elevation: 3.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24.0),
          ),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  blurRadius: 3.0,
                  color: Color(0x33000000),
                  offset: Offset(
                    0.0,
                    1.0,
                  ),
                  spreadRadius: 0.0,
                )
              ],
              borderRadius: BorderRadius.circular(24.0),
              border: Border.all(
                color: Colors.black,
                width: 3.0,
              ),
            ),
            child: Align(
              alignment: AlignmentDirectional(0.0, 0.0),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Text(
                              'Elige lo que mas Prefieras!',
                              style: FlutterFlowTheme.of(context)
                                  .bodySmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 20.0,
                                    letterSpacing: 0.0,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        if (FFAppState().ckeboxx == false)
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Theme(
                                data: ThemeData(
                                  checkboxTheme: CheckboxThemeData(
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4.0),
                                    ),
                                  ),
                                  unselectedWidgetColor:
                                      FlutterFlowTheme.of(context).primaryText,
                                ),
                                child: Checkbox(
                                  value: _model.selectorchekValue ??=
                                      FFAppState().ckeboxx,
                                  onChanged: (newValue) async {
                                    safeSetState(() =>
                                        _model.selectorchekValue = newValue!);
                                    if (newValue!) {
                                      FFAppState().ckeboxx = true;
                                      FFAppState().ckebox1 = false;
                                      FFAppState().selectorcheck = true;
                                      safeSetState(() {});
                                      safeSetState(() {
                                        _model.selectorchekValue =
                                            FFAppState().ckeboxx;
                                      });
                                    } else {
                                      FFAppState().ckeboxx = false;
                                      FFAppState().ckebox1 = false;
                                      safeSetState(() {});
                                      safeSetState(() {
                                        _model.selectorchek2Value =
                                            FFAppState().ckebox1;
                                      });
                                    }
                                  },
                                  side: BorderSide(
                                    width: 2,
                                    color: FlutterFlowTheme.of(context)
                                        .primaryText,
                                  ),
                                  activeColor:
                                      FlutterFlowTheme.of(context).primaryText,
                                  checkColor: FlutterFlowTheme.of(context).info,
                                ),
                              ),
                              Text(
                                'Arroz',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      color: FlutterFlowTheme.of(context)
                                          .primaryText,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ],
                          ),
                        if ((FFAppState().ckebox1 == false) &&
                            (widget!.acompa != 'false'))
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Theme(
                                data: ThemeData(
                                  checkboxTheme: CheckboxThemeData(
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4.0),
                                    ),
                                  ),
                                  unselectedWidgetColor:
                                      FlutterFlowTheme.of(context).primaryText,
                                ),
                                child: Checkbox(
                                  value: _model.selectorchek2Value ??=
                                      FFAppState().ckebox1,
                                  onChanged: (newValue) async {
                                    safeSetState(() =>
                                        _model.selectorchek2Value = newValue!);
                                    if (newValue!) {
                                      FFAppState().ckebox1 = true;
                                      FFAppState().ckeboxx = false;
                                      FFAppState().selectorcheck = true;
                                      safeSetState(() {});
                                      safeSetState(() {
                                        _model.selectorchek2Value =
                                            FFAppState().ckebox1;
                                      });
                                    } else {
                                      FFAppState().ckebox1 = false;
                                      FFAppState().ckeboxx = false;
                                      safeSetState(() {});
                                    }
                                  },
                                  side: BorderSide(
                                    width: 2,
                                    color: FlutterFlowTheme.of(context)
                                        .primaryText,
                                  ),
                                  activeColor:
                                      FlutterFlowTheme.of(context).primaryText,
                                  checkColor: FlutterFlowTheme.of(context).info,
                                ),
                              ),
                              Text(
                                'Otro',
                                style: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      color: FlutterFlowTheme.of(context)
                                          .primaryText,
                                      letterSpacing: 0.0,
                                    ),
                              ),
                            ],
                          ),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        if (FFAppState().ckeboxx == true)
                          Expanded(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Text(
                                  'Arroz',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyLarge
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        color: Color(0xFF101518),
                                        fontSize: 16.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      20.0, 0.0, 20.0, 0.0),
                                  child: Container(
                                    width: double.infinity,
                                    height: 40.0,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(8.0),
                                      border: Border.all(
                                        color: Color(0xFFE0E3E7),
                                        width: 1.0,
                                      ),
                                    ),
                                    child: Align(
                                      alignment:
                                          AlignmentDirectional(0.0, -1.0),
                                      child: FlutterFlowDropDown<String>(
                                        controller: _model
                                                .selector1ValueController ??=
                                            FormFieldController<String>(null),
                                        options: ['Amarrillo', 'Cafe'],
                                        onChanged: (val) async {
                                          safeSetState(() =>
                                              _model.selector1Value = val);
                                          if (_model.selector1Value ==
                                              'Amarrillo') {
                                            FFAppState().cambio =
                                                Color(0xFFC95E04);
                                            safeSetState(() {});
                                          } else {
                                            FFAppState().cambio =
                                                Color(0xFF955A11);
                                            safeSetState(() {});
                                          }

                                          FFAppState().selectordrop = true;
                                          safeSetState(() {});
                                          safeSetState(() {
                                            _model.selector2ValueController
                                                ?.reset();
                                          });
                                        },
                                        width: double.infinity,
                                        height: 40.0,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Readex Pro',
                                              color: Colors.black,
                                              fontSize: 14.0,
                                              letterSpacing: 0.0,
                                              fontWeight: FontWeight.bold,
                                            ),
                                        hintText: 'SELECCIONA EL COLOR',
                                        fillColor: FFAppState().cambio,
                                        elevation: 2.0,
                                        borderColor: Colors.black,
                                        borderWidth: 1.0,
                                        borderRadius: 8.0,
                                        margin: EdgeInsets.all(10.0),
                                        hidesUnderline: true,
                                        isOverButton: false,
                                        isSearchable: false,
                                        isMultiSelect: false,
                                      ),
                                    ),
                                  ),
                                ),
                              ].divide(SizedBox(height: 8.0)),
                            ),
                          ),
                      ].divide(SizedBox(width: 12.0)),
                    ),
                    if (FFAppState().ckebox1 == true)
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            'Otro',
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: 'Readex Pro',
                                      color: Color(0xFF101518),
                                      fontSize: 16.0,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.normal,
                                    ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                20.0, 0.0, 20.0, 20.0),
                            child: Container(
                              width: double.infinity,
                              height: 40.0,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: Color(0xFFE0E3E7),
                                  width: 1.0,
                                ),
                              ),
                              child: FlutterFlowDropDown<String>(
                                controller: _model.selector2ValueController ??=
                                    FormFieldController<String>(null),
                                options: ['Papa'],
                                onChanged: (val) async {
                                  safeSetState(
                                      () => _model.selector2Value = val);
                                  FFAppState().cambio = Color(0xFFC59A52);
                                  safeSetState(() {});
                                  FFAppState().selectordrop = true;
                                  safeSetState(() {});
                                  safeSetState(() {
                                    _model.selector1ValueController?.reset();
                                  });
                                },
                                width: double.infinity,
                                height: 40.0,
                                textStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Readex Pro',
                                      color: Colors.black,
                                      fontSize: 14.0,
                                      letterSpacing: 0.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                hintText: 'SELECCIONA OTRO',
                                fillColor: FFAppState().cambio,
                                elevation: 2.0,
                                borderColor: Colors.black,
                                borderWidth: 1.0,
                                borderRadius: 8.0,
                                margin: EdgeInsets.all(12.0),
                                hidesUnderline: true,
                                isSearchable: false,
                                isMultiSelect: false,
                              ),
                            ),
                          ),
                        ],
                      ),
                    FFButtonWidget(
                      onPressed: () async {
                        FFAppState().cambio = Colors.transparent;
                        FFAppState().aompaant = FFAppState().ckeboxx == true
                            ? _model.selector1Value!
                            : '.';
                        FFAppState().otros = FFAppState().ckebox1 == true
                            ? _model.selector2Value!
                            : '.';
                        FFAppState().acompnante = FFAppState().ckeboxx == true
                            ? _model.selector1Value!
                            : '.';
                        FFAppState().acompaante2 = FFAppState().ckebox1 == true
                            ? _model.selector2Value!
                            : '.';
                        safeSetState(() {});
                        Navigator.pop(context);
                      },
                      text: 'Aceptar 🐼',
                      options: FFButtonOptions(
                        height: 40.0,
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 0.0, 24.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Colors.black,
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.white,
                                  fontSize: 20.0,
                                  letterSpacing: 0.0,
                                ),
                        elevation: 3.0,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(18.0),
                      ),
                    ),
                  ].divide(SizedBox(height: 12.0)),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
