import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'acompanateprivado_widget.dart' show AcompanateprivadoWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AcompanateprivadoModel extends FlutterFlowModel<AcompanateprivadoWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for selectorchek widget.
  bool? selectorchekValue;
  // State field(s) for selectorchek2 widget.
  bool? selectorchek2Value;
  // State field(s) for selector1 widget.
  String? selector1Value;
  FormFieldController<String>? selector1ValueController;
  // State field(s) for selector2 widget.
  String? selector2Value;
  FormFieldController<String>? selector2ValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
