import '/components/carr_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'acompanaytes_widget.dart' show AcompanaytesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AcompanaytesModel extends FlutterFlowModel<AcompanaytesWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for selector1 widget.
  String? selector1Value;
  FormFieldController<String>? selector1ValueController;
  // State field(s) for selector2 widget.
  String? selector2Value;
  FormFieldController<String>? selector2ValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
