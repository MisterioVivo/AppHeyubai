import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/acompanateprivado_widget.dart';
import '/components/alertdrop_widget.dart';
import '/components/carr_widget.dart';
import '/components/observacionplato_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_count_controller.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import '/flutter_flow/custom_functions.dart' as functions;
import 'detalles_prodcuto_widget.dart' show DetallesProdcutoWidget;
import 'package:badges/badges.dart' as badges;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DetallesProdcutoModel extends FlutterFlowModel<DetallesProdcutoWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for CountController widget.
  int? countControllerValue;
  // Model for Observacionplato component.
  late ObservacionplatoModel observacionplatoModel;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  SubProductosRecord? productocreadoExiste;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  Cart2Record? cat2;

  @override
  void initState(BuildContext context) {
    observacionplatoModel = createModel(context, () => ObservacionplatoModel());
  }

  @override
  void dispose() {
    observacionplatoModel.dispose();
  }
}
