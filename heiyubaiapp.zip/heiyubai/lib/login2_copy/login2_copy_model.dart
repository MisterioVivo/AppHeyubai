import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'login2_copy_widget.dart' show Login2CopyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Login2CopyModel extends FlutterFlowModel<Login2CopyWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Correo widget.
  FocusNode? correoFocusNode;
  TextEditingController? correoTextController;
  String? Function(BuildContext, String?)? correoTextControllerValidator;
  // State field(s) for contra1 widget.
  FocusNode? contra1FocusNode;
  TextEditingController? contra1TextController;
  late bool contra1Visibility;
  String? Function(BuildContext, String?)? contra1TextControllerValidator;

  @override
  void initState(BuildContext context) {
    contra1Visibility = false;
  }

  @override
  void dispose() {
    correoFocusNode?.dispose();
    correoTextController?.dispose();

    contra1FocusNode?.dispose();
    contra1TextController?.dispose();
  }
}
