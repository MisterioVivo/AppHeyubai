// Export pages
export '/login/login_widget.dart' show LoginWidget;
export '/login2/login2_widget.dart' show Login2Widget;
export '/menu1/menu1_widget.dart' show Menu1Widget;
export '/detalles_prodcuto/detalles_prodcuto_widget.dart'
    show DetallesProdcutoWidget;
export '/carrito/carrito_widget.dart' show CarritoWidget;
export '/form/form_widget.dart' show FormWidget;
export '/login2_copy/login2_copy_widget.dart' show Login2CopyWidget;
export '/detallesde_pago/detallesde_pago_widget.dart' show DetallesdePagoWidget;
export '/paginasdecarga/paginasdecarga_widget.dart' show PaginasdecargaWidget;
export '/prfilusuario/prfilusuario_widget.dart' show PrfilusuarioWidget;
export '/terminosycondiciones/terminosycondiciones_widget.dart'
    show TerminosycondicionesWidget;
export '/pagos/logpago/logpago_widget.dart' show LogpagoWidget;
export '/pagos/pagexito/pagexito_widget.dart' show PagexitoWidget;
export '/pagos/pagfallido/pagfallido_widget.dart' show PagfallidoWidget;
export '/pagos/procesopago/procesopago_widget.dart' show ProcesopagoWidget;
export '/contraentregafinalizada/contraentregafinalizada_widget.dart'
    show ContraentregafinalizadaWidget;
export '/estado/estado_widget.dart' show EstadoWidget;
