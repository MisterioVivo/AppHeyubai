import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/auth/firebase_auth/auth_util.dart';

double subtotalItem(
  int cantidad,
  double precio,
) {
  return cantidad * precio;
}

double? totalvalue(double cantidad) {
  return cantidad;
}

List<DocumentReference> getRangeItemsList(
  int minRange,
  int maxRange,
  List<DocumentReference> itemList,
) {
  List<DocumentReference> rangeItemList = [];

  for (int i = 0; i < itemList.length; i++) {
    if (i >= minRange && i <= maxRange) {
      rangeItemList.add(itemList[i]);
    }
  }

  return rangeItemList;
}

int codigorandom() {
  // Give me a code that generates 5-digit random numbers It must be integers
  return math.Random().nextInt(90000) + 10000;
}
