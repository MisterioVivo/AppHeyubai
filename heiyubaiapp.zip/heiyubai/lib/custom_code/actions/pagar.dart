// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_custom_tabs/flutter_custom_tabs.dart'; // Asegúrate de que esta librería está en pubspec.yaml

Future<void> pagar(
  String? url,
  Color? color,
) async {
  // Asegúrate de que la URL y el color no sean nulos
  if (url == null || color == null) {
    throw ArgumentError('La URL y el color no pueden ser nulos');
  }

  // URLs específicas a limpiar
  const specialUrls = [
    "http://heiyubai://heiyubai.com/PAGOFALLIDO"
        "http://heiyubai://heiyubai.com/PAGOFALLIDO"
        "http://heiyubai://heiyubai.com/PAGOEXITO"
  ];

  // Limpia la URL si es una de las especiales
  String cleanedUrl;
  if (specialUrls.contains(url)) {
    cleanedUrl = _removeUrlParameters(url);
  } else {
    cleanedUrl = url; // Mantiene la URL original
  }

  try {
    await launchUrl(
      Uri.parse(cleanedUrl),
      customTabsOptions: CustomTabsOptions(
        colorSchemes: CustomTabsColorSchemes.defaults(
          toolbarColor: color,
        ),
        shareState: CustomTabsShareState.on,
        urlBarHidingEnabled: true,
        showTitle: true,
        closeButton: CustomTabsCloseButton(
          icon: CustomTabsCloseButtonIcons.back,
        ),
      ),
      safariVCOptions: SafariViewControllerOptions(
        preferredBarTintColor: color,
        preferredControlTintColor: color,
        barCollapsingEnabled: true,
        dismissButtonStyle: SafariViewControllerDismissButtonStyle.close,
      ),
    );
  } catch (e) {
    // Maneja cualquier error que ocurra al abrir la URL
    print('Error al abrir la URL: $e');
  }
}

// Función para limpiar la URL
String _removeUrlParameters(String url) {
  final uri = Uri.parse(url);
  return uri.scheme +
      '://' +
      uri.host +
      uri.path; // Retorna solo el esquema, host y path
}
