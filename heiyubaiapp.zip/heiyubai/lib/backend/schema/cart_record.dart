import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CartRecord extends FirestoreRecord {
  CartRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "productCount" field.
  int? _productCount;
  int get productCount => _productCount ?? 0;
  bool hasProductCount() => _productCount != null;

  // "isActive" field.
  bool? _isActive;
  bool get isActive => _isActive ?? false;
  bool hasIsActive() => _isActive != null;

  // "cantidad" field.
  double? _cantidad;
  double get cantidad => _cantidad ?? 0.0;
  bool hasCantidad() => _cantidad != null;

  // "selectItemsList" field.
  List<DocumentReference>? _selectItemsList;
  List<DocumentReference> get selectItemsList => _selectItemsList ?? const [];
  bool hasSelectItemsList() => _selectItemsList != null;

  // "stado" field.
  bool? _stado;
  bool get stado => _stado ?? false;
  bool hasStado() => _stado != null;

  // "creator" field.
  DocumentReference? _creator;
  DocumentReference? get creator => _creator;
  bool hasCreator() => _creator != null;

  // "ky" field.
  String? _ky;
  String get ky => _ky ?? '';
  bool hasKy() => _ky != null;

  // "carrito" field.
  int? _carrito;
  int get carrito => _carrito ?? 0;
  bool hasCarrito() => _carrito != null;

  void _initializeFields() {
    _productCount = castToType<int>(snapshotData['productCount']);
    _isActive = snapshotData['isActive'] as bool?;
    _cantidad = castToType<double>(snapshotData['cantidad']);
    _selectItemsList = getDataList(snapshotData['selectItemsList']);
    _stado = snapshotData['stado'] as bool?;
    _creator = snapshotData['creator'] as DocumentReference?;
    _ky = snapshotData['ky'] as String?;
    _carrito = castToType<int>(snapshotData['carrito']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('cart');

  static Stream<CartRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CartRecord.fromSnapshot(s));

  static Future<CartRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CartRecord.fromSnapshot(s));

  static CartRecord fromSnapshot(DocumentSnapshot snapshot) => CartRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CartRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CartRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CartRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CartRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCartRecordData({
  int? productCount,
  bool? isActive,
  double? cantidad,
  bool? stado,
  DocumentReference? creator,
  String? ky,
  int? carrito,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'productCount': productCount,
      'isActive': isActive,
      'cantidad': cantidad,
      'stado': stado,
      'creator': creator,
      'ky': ky,
      'carrito': carrito,
    }.withoutNulls,
  );

  return firestoreData;
}

class CartRecordDocumentEquality implements Equality<CartRecord> {
  const CartRecordDocumentEquality();

  @override
  bool equals(CartRecord? e1, CartRecord? e2) {
    const listEquality = ListEquality();
    return e1?.productCount == e2?.productCount &&
        e1?.isActive == e2?.isActive &&
        e1?.cantidad == e2?.cantidad &&
        listEquality.equals(e1?.selectItemsList, e2?.selectItemsList) &&
        e1?.stado == e2?.stado &&
        e1?.creator == e2?.creator &&
        e1?.ky == e2?.ky &&
        e1?.carrito == e2?.carrito;
  }

  @override
  int hash(CartRecord? e) => const ListEquality().hash([
        e?.productCount,
        e?.isActive,
        e?.cantidad,
        e?.selectItemsList,
        e?.stado,
        e?.creator,
        e?.ky,
        e?.carrito
      ]);

  @override
  bool isValidKey(Object? o) => o is CartRecord;
}
