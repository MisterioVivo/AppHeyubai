import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PdidospagosRecord extends FirestoreRecord {
  PdidospagosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "dirccion" field.
  String? _dirccion;
  String get dirccion => _dirccion ?? '';
  bool hasDirccion() => _dirccion != null;

  // "zona" field.
  String? _zona;
  String get zona => _zona ?? '';
  bool hasZona() => _zona != null;

  // "barrio" field.
  String? _barrio;
  String get barrio => _barrio ?? '';
  bool hasBarrio() => _barrio != null;

  // "numro" field.
  String? _numro;
  String get numro => _numro ?? '';
  bool hasNumro() => _numro != null;

  // "nombr" field.
  String? _nombr;
  String get nombr => _nombr ?? '';
  bool hasNombr() => _nombr != null;

  // "adisional" field.
  String? _adisional;
  String get adisional => _adisional ?? '';
  bool hasAdisional() => _adisional != null;

  // "rf" field.
  List<DocumentReference>? _rf;
  List<DocumentReference> get rf => _rf ?? const [];
  bool hasRf() => _rf != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "fecha" field.
  DateTime? _fecha;
  DateTime? get fecha => _fecha;
  bool hasFecha() => _fecha != null;

  // "stado" field.
  bool? _stado;
  bool get stado => _stado ?? false;
  bool hasStado() => _stado != null;

  // "acompaant" field.
  String? _acompaant;
  String get acompaant => _acompaant ?? '';
  bool hasAcompaant() => _acompaant != null;

  // "rfusr" field.
  DocumentReference? _rfusr;
  DocumentReference? get rfusr => _rfusr;
  bool hasRfusr() => _rfusr != null;

  // "otro" field.
  String? _otro;
  String get otro => _otro ?? '';
  bool hasOtro() => _otro != null;

  // "estado" field.
  String? _estado;
  String get estado => _estado ?? '';
  bool hasEstado() => _estado != null;

  // "aco" field.
  String? _aco;
  String get aco => _aco ?? '';
  bool hasAco() => _aco != null;

  // "tickect" field.
  int? _tickect;
  int get tickect => _tickect ?? 0;
  bool hasTickect() => _tickect != null;

  // "cart2" field.
  DocumentReference? _cart2;
  DocumentReference? get cart2 => _cart2;
  bool hasCart2() => _cart2 != null;

  // "cart" field.
  DocumentReference? _cart;
  DocumentReference? get cart => _cart;
  bool hasCart() => _cart != null;

  void _initializeFields() {
    _dirccion = snapshotData['dirccion'] as String?;
    _zona = snapshotData['zona'] as String?;
    _barrio = snapshotData['barrio'] as String?;
    _numro = snapshotData['numro'] as String?;
    _nombr = snapshotData['nombr'] as String?;
    _adisional = snapshotData['adisional'] as String?;
    _rf = getDataList(snapshotData['rf']);
    _email = snapshotData['email'] as String?;
    _fecha = snapshotData['fecha'] as DateTime?;
    _stado = snapshotData['stado'] as bool?;
    _acompaant = snapshotData['acompaant'] as String?;
    _rfusr = snapshotData['rfusr'] as DocumentReference?;
    _otro = snapshotData['otro'] as String?;
    _estado = snapshotData['estado'] as String?;
    _aco = snapshotData['aco'] as String?;
    _tickect = castToType<int>(snapshotData['tickect']);
    _cart2 = snapshotData['cart2'] as DocumentReference?;
    _cart = snapshotData['cart'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('pdidospagos');

  static Stream<PdidospagosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PdidospagosRecord.fromSnapshot(s));

  static Future<PdidospagosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PdidospagosRecord.fromSnapshot(s));

  static PdidospagosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PdidospagosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PdidospagosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PdidospagosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PdidospagosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PdidospagosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPdidospagosRecordData({
  String? dirccion,
  String? zona,
  String? barrio,
  String? numro,
  String? nombr,
  String? adisional,
  String? email,
  DateTime? fecha,
  bool? stado,
  String? acompaant,
  DocumentReference? rfusr,
  String? otro,
  String? estado,
  String? aco,
  int? tickect,
  DocumentReference? cart2,
  DocumentReference? cart,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'dirccion': dirccion,
      'zona': zona,
      'barrio': barrio,
      'numro': numro,
      'nombr': nombr,
      'adisional': adisional,
      'email': email,
      'fecha': fecha,
      'stado': stado,
      'acompaant': acompaant,
      'rfusr': rfusr,
      'otro': otro,
      'estado': estado,
      'aco': aco,
      'tickect': tickect,
      'cart2': cart2,
      'cart': cart,
    }.withoutNulls,
  );

  return firestoreData;
}

class PdidospagosRecordDocumentEquality implements Equality<PdidospagosRecord> {
  const PdidospagosRecordDocumentEquality();

  @override
  bool equals(PdidospagosRecord? e1, PdidospagosRecord? e2) {
    const listEquality = ListEquality();
    return e1?.dirccion == e2?.dirccion &&
        e1?.zona == e2?.zona &&
        e1?.barrio == e2?.barrio &&
        e1?.numro == e2?.numro &&
        e1?.nombr == e2?.nombr &&
        e1?.adisional == e2?.adisional &&
        listEquality.equals(e1?.rf, e2?.rf) &&
        e1?.email == e2?.email &&
        e1?.fecha == e2?.fecha &&
        e1?.stado == e2?.stado &&
        e1?.acompaant == e2?.acompaant &&
        e1?.rfusr == e2?.rfusr &&
        e1?.otro == e2?.otro &&
        e1?.estado == e2?.estado &&
        e1?.aco == e2?.aco &&
        e1?.tickect == e2?.tickect &&
        e1?.cart2 == e2?.cart2 &&
        e1?.cart == e2?.cart;
  }

  @override
  int hash(PdidospagosRecord? e) => const ListEquality().hash([
        e?.dirccion,
        e?.zona,
        e?.barrio,
        e?.numro,
        e?.nombr,
        e?.adisional,
        e?.rf,
        e?.email,
        e?.fecha,
        e?.stado,
        e?.acompaant,
        e?.rfusr,
        e?.otro,
        e?.estado,
        e?.aco,
        e?.tickect,
        e?.cart2,
        e?.cart
      ]);

  @override
  bool isValidKey(Object? o) => o is PdidospagosRecord;
}
