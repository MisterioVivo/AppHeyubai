import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsuariosRecord extends FirestoreRecord {
  UsuariosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "pago" field.
  bool? _pago;
  bool get pago => _pago ?? false;
  bool hasPago() => _pago != null;

  // "productos" field.
  List<DocumentReference>? _productos;
  List<DocumentReference> get productos => _productos ?? const [];
  bool hasProductos() => _productos != null;

  // "cart" field.
  DocumentReference? _cart;
  DocumentReference? get cart => _cart;
  bool hasCart() => _cart != null;

  // "adisional" field.
  String? _adisional;
  String get adisional => _adisional ?? '';
  bool hasAdisional() => _adisional != null;

  // "barrio" field.
  String? _barrio;
  String get barrio => _barrio ?? '';
  bool hasBarrio() => _barrio != null;

  // "dirrcion" field.
  String? _dirrcion;
  String get dirrcion => _dirrcion ?? '';
  bool hasDirrcion() => _dirrcion != null;

  // "nombr" field.
  String? _nombr;
  String get nombr => _nombr ?? '';
  bool hasNombr() => _nombr != null;

  // "numro" field.
  String? _numro;
  String get numro => _numro ?? '';
  bool hasNumro() => _numro != null;

  // "zona" field.
  String? _zona;
  String get zona => _zona ?? '';
  bool hasZona() => _zona != null;

  // "acompaant" field.
  String? _acompaant;
  String get acompaant => _acompaant ?? '';
  bool hasAcompaant() => _acompaant != null;

  // "otro" field.
  String? _otro;
  String get otro => _otro ?? '';
  bool hasOtro() => _otro != null;

  // "cart2" field.
  DocumentReference? _cart2;
  DocumentReference? get cart2 => _cart2;
  bool hasCart2() => _cart2 != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _pago = snapshotData['pago'] as bool?;
    _productos = getDataList(snapshotData['productos']);
    _cart = snapshotData['cart'] as DocumentReference?;
    _adisional = snapshotData['adisional'] as String?;
    _barrio = snapshotData['barrio'] as String?;
    _dirrcion = snapshotData['dirrcion'] as String?;
    _nombr = snapshotData['nombr'] as String?;
    _numro = snapshotData['numro'] as String?;
    _zona = snapshotData['zona'] as String?;
    _acompaant = snapshotData['acompaant'] as String?;
    _otro = snapshotData['otro'] as String?;
    _cart2 = snapshotData['cart2'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('usuarios');

  static Stream<UsuariosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsuariosRecord.fromSnapshot(s));

  static Future<UsuariosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsuariosRecord.fromSnapshot(s));

  static UsuariosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UsuariosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsuariosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsuariosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsuariosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsuariosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsuariosRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  bool? pago,
  DocumentReference? cart,
  String? adisional,
  String? barrio,
  String? dirrcion,
  String? nombr,
  String? numro,
  String? zona,
  String? acompaant,
  String? otro,
  DocumentReference? cart2,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'pago': pago,
      'cart': cart,
      'adisional': adisional,
      'barrio': barrio,
      'dirrcion': dirrcion,
      'nombr': nombr,
      'numro': numro,
      'zona': zona,
      'acompaant': acompaant,
      'otro': otro,
      'cart2': cart2,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsuariosRecordDocumentEquality implements Equality<UsuariosRecord> {
  const UsuariosRecordDocumentEquality();

  @override
  bool equals(UsuariosRecord? e1, UsuariosRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.pago == e2?.pago &&
        listEquality.equals(e1?.productos, e2?.productos) &&
        e1?.cart == e2?.cart &&
        e1?.adisional == e2?.adisional &&
        e1?.barrio == e2?.barrio &&
        e1?.dirrcion == e2?.dirrcion &&
        e1?.nombr == e2?.nombr &&
        e1?.numro == e2?.numro &&
        e1?.zona == e2?.zona &&
        e1?.acompaant == e2?.acompaant &&
        e1?.otro == e2?.otro &&
        e1?.cart2 == e2?.cart2;
  }

  @override
  int hash(UsuariosRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.pago,
        e?.productos,
        e?.cart,
        e?.adisional,
        e?.barrio,
        e?.dirrcion,
        e?.nombr,
        e?.numro,
        e?.zona,
        e?.acompaant,
        e?.otro,
        e?.cart2
      ]);

  @override
  bool isValidKey(Object? o) => o is UsuariosRecord;
}
