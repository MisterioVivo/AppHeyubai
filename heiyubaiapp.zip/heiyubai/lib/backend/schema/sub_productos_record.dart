import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SubProductosRecord extends FirestoreRecord {
  SubProductosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "cantidad" field.
  int? _cantidad;
  int get cantidad => _cantidad ?? 0;
  bool hasCantidad() => _cantidad != null;

  // "subtotal" field.
  double? _subtotal;
  double get subtotal => _subtotal ?? 0.0;
  bool hasSubtotal() => _subtotal != null;

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "precio" field.
  double? _precio;
  double get precio => _precio ?? 0.0;
  bool hasPrecio() => _precio != null;

  // "imagen" field.
  String? _imagen;
  String get imagen => _imagen ?? '';
  bool hasImagen() => _imagen != null;

  // "tiempo" field.
  DateTime? _tiempo;
  DateTime? get tiempo => _tiempo;
  bool hasTiempo() => _tiempo != null;

  // "productos" field.
  DocumentReference? _productos;
  DocumentReference? get productos => _productos;
  bool hasProductos() => _productos != null;

  // "cart" field.
  DocumentReference? _cart;
  DocumentReference? get cart => _cart;
  bool hasCart() => _cart != null;

  // "creador" field.
  DocumentReference? _creador;
  DocumentReference? get creador => _creador;
  bool hasCreador() => _creador != null;

  // "selector1" field.
  String? _selector1;
  String get selector1 => _selector1 ?? '';
  bool hasSelector1() => _selector1 != null;

  // "selector2" field.
  String? _selector2;
  String get selector2 => _selector2 ?? '';
  bool hasSelector2() => _selector2 != null;

  // "ubi" field.
  String? _ubi;
  String get ubi => _ubi ?? '';
  bool hasUbi() => _ubi != null;

  // "dscrpcionusuario" field.
  String? _dscrpcionusuario;
  String get dscrpcionusuario => _dscrpcionusuario ?? '';
  bool hasDscrpcionusuario() => _dscrpcionusuario != null;

  void _initializeFields() {
    _cantidad = castToType<int>(snapshotData['cantidad']);
    _subtotal = castToType<double>(snapshotData['subtotal']);
    _nombre = snapshotData['nombre'] as String?;
    _precio = castToType<double>(snapshotData['precio']);
    _imagen = snapshotData['imagen'] as String?;
    _tiempo = snapshotData['tiempo'] as DateTime?;
    _productos = snapshotData['productos'] as DocumentReference?;
    _cart = snapshotData['cart'] as DocumentReference?;
    _creador = snapshotData['creador'] as DocumentReference?;
    _selector1 = snapshotData['selector1'] as String?;
    _selector2 = snapshotData['selector2'] as String?;
    _ubi = snapshotData['ubi'] as String?;
    _dscrpcionusuario = snapshotData['dscrpcionusuario'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('subProductos');

  static Stream<SubProductosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SubProductosRecord.fromSnapshot(s));

  static Future<SubProductosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SubProductosRecord.fromSnapshot(s));

  static SubProductosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SubProductosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SubProductosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SubProductosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SubProductosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SubProductosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSubProductosRecordData({
  int? cantidad,
  double? subtotal,
  String? nombre,
  double? precio,
  String? imagen,
  DateTime? tiempo,
  DocumentReference? productos,
  DocumentReference? cart,
  DocumentReference? creador,
  String? selector1,
  String? selector2,
  String? ubi,
  String? dscrpcionusuario,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'cantidad': cantidad,
      'subtotal': subtotal,
      'nombre': nombre,
      'precio': precio,
      'imagen': imagen,
      'tiempo': tiempo,
      'productos': productos,
      'cart': cart,
      'creador': creador,
      'selector1': selector1,
      'selector2': selector2,
      'ubi': ubi,
      'dscrpcionusuario': dscrpcionusuario,
    }.withoutNulls,
  );

  return firestoreData;
}

class SubProductosRecordDocumentEquality
    implements Equality<SubProductosRecord> {
  const SubProductosRecordDocumentEquality();

  @override
  bool equals(SubProductosRecord? e1, SubProductosRecord? e2) {
    return e1?.cantidad == e2?.cantidad &&
        e1?.subtotal == e2?.subtotal &&
        e1?.nombre == e2?.nombre &&
        e1?.precio == e2?.precio &&
        e1?.imagen == e2?.imagen &&
        e1?.tiempo == e2?.tiempo &&
        e1?.productos == e2?.productos &&
        e1?.cart == e2?.cart &&
        e1?.creador == e2?.creador &&
        e1?.selector1 == e2?.selector1 &&
        e1?.selector2 == e2?.selector2 &&
        e1?.ubi == e2?.ubi &&
        e1?.dscrpcionusuario == e2?.dscrpcionusuario;
  }

  @override
  int hash(SubProductosRecord? e) => const ListEquality().hash([
        e?.cantidad,
        e?.subtotal,
        e?.nombre,
        e?.precio,
        e?.imagen,
        e?.tiempo,
        e?.productos,
        e?.cart,
        e?.creador,
        e?.selector1,
        e?.selector2,
        e?.ubi,
        e?.dscrpcionusuario
      ]);

  @override
  bool isValidKey(Object? o) => o is SubProductosRecord;
}
