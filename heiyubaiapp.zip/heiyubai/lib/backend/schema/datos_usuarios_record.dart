import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DatosUsuariosRecord extends FirestoreRecord {
  DatosUsuariosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Direccion" field.
  String? _direccion;
  String get direccion => _direccion ?? '';
  bool hasDireccion() => _direccion != null;

  // "Barrio" field.
  String? _barrio;
  String get barrio => _barrio ?? '';
  bool hasBarrio() => _barrio != null;

  // "Nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "Zona" field.
  String? _zona;
  String get zona => _zona ?? '';
  bool hasZona() => _zona != null;

  // "Informacion" field.
  String? _informacion;
  String get informacion => _informacion ?? '';
  bool hasInformacion() => _informacion != null;

  // "Numero" field.
  String? _numero;
  String get numero => _numero ?? '';
  bool hasNumero() => _numero != null;

  // "ubi" field.
  LatLng? _ubi;
  LatLng? get ubi => _ubi;
  bool hasUbi() => _ubi != null;

  void _initializeFields() {
    _direccion = snapshotData['Direccion'] as String?;
    _barrio = snapshotData['Barrio'] as String?;
    _nombre = snapshotData['Nombre'] as String?;
    _zona = snapshotData['Zona'] as String?;
    _informacion = snapshotData['Informacion'] as String?;
    _numero = snapshotData['Numero'] as String?;
    _ubi = snapshotData['ubi'] as LatLng?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('datosUsuarios');

  static Stream<DatosUsuariosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DatosUsuariosRecord.fromSnapshot(s));

  static Future<DatosUsuariosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DatosUsuariosRecord.fromSnapshot(s));

  static DatosUsuariosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DatosUsuariosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DatosUsuariosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DatosUsuariosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DatosUsuariosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DatosUsuariosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDatosUsuariosRecordData({
  String? direccion,
  String? barrio,
  String? nombre,
  String? zona,
  String? informacion,
  String? numero,
  LatLng? ubi,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Direccion': direccion,
      'Barrio': barrio,
      'Nombre': nombre,
      'Zona': zona,
      'Informacion': informacion,
      'Numero': numero,
      'ubi': ubi,
    }.withoutNulls,
  );

  return firestoreData;
}

class DatosUsuariosRecordDocumentEquality
    implements Equality<DatosUsuariosRecord> {
  const DatosUsuariosRecordDocumentEquality();

  @override
  bool equals(DatosUsuariosRecord? e1, DatosUsuariosRecord? e2) {
    return e1?.direccion == e2?.direccion &&
        e1?.barrio == e2?.barrio &&
        e1?.nombre == e2?.nombre &&
        e1?.zona == e2?.zona &&
        e1?.informacion == e2?.informacion &&
        e1?.numero == e2?.numero &&
        e1?.ubi == e2?.ubi;
  }

  @override
  int hash(DatosUsuariosRecord? e) => const ListEquality().hash([
        e?.direccion,
        e?.barrio,
        e?.nombre,
        e?.zona,
        e?.informacion,
        e?.numero,
        e?.ubi
      ]);

  @override
  bool isValidKey(Object? o) => o is DatosUsuariosRecord;
}
