import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class CrearPreferenciasCall {
  static Future<ApiCallResponse> call({
    String? id = '',
    String? zipCode = '',
    double? streetNumber,
    String? streetName = '',
    double? precio,
    String? descripcion = '',
    String? titulo = '',
    String? pending = '',
    String? failure = '',
    String? success = '',
    int? number,
    String? email = '',
    String? surname = '',
    String? name = '',
  }) async {
    final ffApiRequestBody = '''
{
  "items": [
    {
      "id": "${id}",
      "title": "${titulo}",
      "description": "${titulo}",
      "quantity": 1,
      "currency_id": "COP",
      "unit_price": ${precio}
    }
  ],
  "payer": {
    "name": "${name}",
    "surname": "${surname}",
    "email": "${email}",
    "phone": {
      "area_code": "11",
      "number": ${number}
    },
    "identification": {
      "type": "CC",
      "number": "12345678"
    },
    "address": {
      "street_name": "${streetName}",
      "street_number": ${streetNumber},
      "zip_code": "${zipCode}"
    }
  },
  "back_urls": {
    "success": "${success}",
    "failure": "${failure}",
    "pending": "${pending}"
  },
"auto_return": "approved",
  "payment_methods": {
    "excluded_payment_methods": [
      {
        "id": "amex"
      }
    ],
    "excluded_payment_types": [
      {
        "id": "atm"
      }
    ],
    "installments": 1
  },
  "notification_url": "https://www.example.com/notifications",
  "statement_descriptor": "MiTienda",
  "external_reference": "123456789"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'CrearPreferencias',
      apiUrl: 'https://api.mercadopago.com/checkout/preferences',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer TEST-5306795117040175-082917-95d83a452d6b51c56d8ed28e1eff6917-1969375526',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? url(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.init_point''',
      ));
}

class ReferenciaCall {
  static Future<ApiCallResponse> call({
    String? id = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'referencia',
      apiUrl: 'https://api.mercadopago.com/checkout/preferences/${id}',
      callType: ApiCallType.GET,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer TEST-5306795117040175-082917-95d83a452d6b51c56d8ed28e1eff6917-1969375526',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? url(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.sandbox_init_point''',
      ));
  static dynamic? pago(dynamic response) => getJsonField(
        response,
        r'''$.redirect_urls''',
      );
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
