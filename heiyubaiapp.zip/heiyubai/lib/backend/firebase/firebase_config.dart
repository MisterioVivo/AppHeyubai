import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDQIBQosQ-OY0XpG_0baR3RiuSrgCI2kac",
            authDomain: "boxwood-tree-437122-s0.firebaseapp.com",
            projectId: "boxwood-tree-437122-s0",
            storageBucket: "boxwood-tree-437122-s0.appspot.com",
            messagingSenderId: "347815382496",
            appId: "1:347815382496:web:a30ada1027d16d24d26f85",
            measurementId: "G-HKK7DKVYKW"));
  } else {
    await Firebase.initializeApp();
  }
}
